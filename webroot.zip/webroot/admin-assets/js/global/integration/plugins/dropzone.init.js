Dropzone.autoDiscover = false;
